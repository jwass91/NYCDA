phrase = gets.chomp

america = " only in America!"

puts phrase + america
