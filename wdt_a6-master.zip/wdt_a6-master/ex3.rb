brand = [:nike, :addias]
shoe = ["lerbon", "springblade"]

puts Hash[brand.zip(shoe)]
